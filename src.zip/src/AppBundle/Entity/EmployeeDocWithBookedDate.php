<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 23/2/18
 * Time: 11:03 AM
 */

namespace AppBundle\Entity;



class EmployeeDocWithBookedDate {
    public $docs;

    public $bookedDates;


}