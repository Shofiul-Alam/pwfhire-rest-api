<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 9/11/2017
 * Time: 10:59 AM
 */

namespace BackendBundle\Entity\Bundle;



interface EntityInterface {


}